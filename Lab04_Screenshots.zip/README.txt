﻿Lab 04 — BJT CE Amplifier Simulator : screenshot evidence
=========================================================
Final browser captures (port 5000, after Impeccable polish):

final-B1-divider.jpeg  - Analytical DC Bias, Voltage Divider
final-B1-fixed.jpeg    - Analytical DC Bias, Fixed
final-B1-emitter.jpeg  - Analytical DC Bias, Emitter
final-B2-dc.jpeg       - SPICE DC operating point (.op)
final-B3-re.jpeg       - SPICE DC after RE 1k -> 1.5k
final-B4-ac.jpeg       - SPICE AC Bode: gain + phase (.ac)  [GRAPH]
final-B5-tran.jpeg     - SPICE transient 10 mV @ 1 kHz      [GRAPH]
final-B6-source.jpeg   - SPICE transient 20 mV @ 2 kHz      [GRAPH]
final-B7-invalid.jpeg  - Error state RE = 0 (no fake result)

Impeccable UI proof:
1440x900.png           - desktop root after polish
390x844.png            - phone root after polish

Note: BJT model used for SPICE captures is PN2222 from ngspice 47
example (FALLBACK_MODEL_NOT_INSTRUCTOR), not the instructor Starter Kit.
Replace models/bjt.model and re-run before final submission if required.
